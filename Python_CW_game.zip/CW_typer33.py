""" 
A simple CW Game 
by B. Anding
September 16, 2020
for personal use only:
CW game is a Morse code game which uses a text file as an input. 
Text files can be created with a text editing program, IE. notepad.
The text file is enter one entry per line, hit return and 
enter another entry on the next line, etc. Each line can contain 
a letter, number, word or a sentence.
CW Game opens a window, at the top click "file" then "open" next
select a text file and click open and CW Game starts 
by B. Anding
9-21-2020
for personal use only
"""
from tkinter import *
from tkinter.filedialog import askopenfilename
import pygame as pg

screen = pg.display.set_mode((1200, 800), 0, 32)
pg.init()

import random
import sys
import os




# wait for a while to show the window.
import time
time.sleep(2)


def main():
   
    global root
    def NewFile():
        print("New File!")
    def OpenFile():
        f_name = askopenfilename()
        new_word(f_name)
        root.iconify()
    def About():
        print("CW game By B. Anding")
        
    root = Tk()
    root.geometry("600x400")
    root.title("CW Game")
    image1= PhotoImage(file ="key_Drawing25.png")
    label_for_image= Label(root, image=image1)
    label_for_image.pack()
    menu = Menu(root)
    root.config(menu=menu)
    filemenu = Menu(menu)
    filemenu = Menu(menu, tearoff=0)
    menu.add_cascade(label="File", menu=filemenu)
    filemenu.add_command(label="New", command=NewFile)
    filemenu.add_command(label="Open...", command=OpenFile)
    filemenu.add_separator()
    filemenu.add_command(label="Exit", command=root.quit)
    
    helpmenu = Menu(menu)
    helpmenu = Menu(menu, tearoff=0)
    menu.add_cascade(label="Help", menu=helpmenu)
    helpmenu.add_command(label="by B. Anding", command=About)
    label = Label( root, text ="Choose file, then open and select file and open", font=(None,18),anchor=N, justify =CENTER)
    label.place(relx = 0.5, rely = 0, anchor="n",) #label.pack()
    label1 = Label( root,text ="ESC = QUIT        F1 = RESTART", font=(None,18))
    label1.place(relx = 0.5, rely = 1.0, anchor="s",)
                 
    mainloop()
    
""" Typing Game uses a file_word file as input and reads keyboard for responce  """

def play_game(file_word):
    global screen, score    
    """ redraw screen play game """
    pg.display.set_caption("CW Game")
    font = pg.font.SysFont(None, 48) #("Arial Black", 24)
    bg = (230,230,230)
    red = (255,0,0)
    green = (100,220,100) # muted green
    blue = (0,0,255)
    entry_X = 30
    entry_Y = 0
    X = 1200
    Y = 800
    speed = 0.3
    score = 0
    color = blue
    ans_word = ""
    char = ""
    root.destroy() # close menu screen
    
    while True:
        
        screen.fill(bg)
        entry_Y += speed
        if entry_Y >= 795:
            end_screen()
        text = font.render(file_word, True, blue)
        wrd_len = text.get_width()
        if wrd_len + entry_X >= X:
            entry_X = X - wrd_len
            print(wrd_len)
        screen.blit(text, (entry_X, int(entry_Y)))
        color = red
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                quit()
            elif event.type == pg.KEYDOWN:
                char = pg.key.name(event.key)
                if char == "space":
                    char = ' '
                ans_word += char 
                if file_word.startswith(ans_word):
                    if file_word == ans_word:
                        entry = font.render(ans_word, True, color)
                        score += len(file_word)
                        speed += 0.03
                        entry_X = random.randint(90,1170)
                        entry_Y = 0
                        file_word = random.choice(lines)
                        file_word = file_word.lower()
                        file_word = (file_word.rstrip('\n'))
                        ans_word = ""
                else:
                    ans_word = ""
                    char = ""
                    
        entry = font.render(ans_word, True, color)
       
        screen.blit(entry, (entry_X, int(entry_Y)))
        scoreCaption = font.render(str(score), True, green)
        screen.blit(scoreCaption, (10,15))
        if (entry_Y) < Y-5:
            pg.display.flip()
        else:
            event = pg.event.wait()
        
        if event.type == pg.KEYDOWN and event.key == pg.K_F1:
            speed = 0.03
            score = 0
            entry_Y = 0
            
        elif event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE:
            end_screen()

def new_word(f_name):
    global lines
    # open word file and randomly prenders on screen  
    entry_X = random.randint(90,1170) # keep in window
    entry_Y = 0
    ans_word = ""
    with open(f_name) as file_object:
        lines = file_object.readlines()
    # choose word, lower case, strip '\n' char
    file_word = random.choice(lines)
    file_word = file_word.lower()
    file_word =(file_word.rstrip('\n'))
    play_game(file_word) 
    
def end_screen():
    font = pg.font.SysFont(None, 72)
    end_scr = font.render("GAME OVER", True, (10,0,0))
    screen.blit(end_scr, (400, 300))
    font = pg.font.SysFont(None, 48)
    end_scr = font.render("Score = " + str(score), True, (255,0,0))
    screen.blit(end_scr, (450, 400))
    pg.display.update()
    time.sleep(3) # Wait for 2 seconds
    pg.quit()
    sys.exit()

if __name__ == '__main__':
    pg.init()
    main()
    pg.quit()
    sys.exit()

